package com.epam.learning;

public class MathUtils {
    private final Calculator calculator;

    public MathUtils(Calculator calculator) {
        this.calculator = calculator;
    }

    /* This method returns sum of 2 numbers */
    public int sumOfTwoNumbers(int n1, int n2) {
        return calculator.sumOfTwoNumbers(n1, n2);
    }

    /* This method returns multiplication of 2 numbers */
    public int multiplicationOfTwoNumbers(int n1, int n2) {
        return calculator.multiplicationOfTwoNumbers(n1, n2);
    }

    /* This method returns true or false for the given integer number */
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }

    /* This method returns true or false for the given integer number */
    private boolean isOdd(int number) {
        return number % 2 != 0;
    }

    public final String finalMessage() {
        return "Hello World!";
    }
}

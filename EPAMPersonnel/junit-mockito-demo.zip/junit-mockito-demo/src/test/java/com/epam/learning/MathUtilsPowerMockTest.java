package com.epam.learning;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

@RunWith(PowerMockRunner.class)
@PrepareForTest(MathUtils.class)
public class MathUtilsPowerMockTest {

    /* static method mocking*/
    @Test
    public void shouldReturnTrueForTheGivenEvenNumber(){
        //Mock static method
        PowerMockito.mockStatic(MathUtils.class);

        //Set expectation
        PowerMockito.when(MathUtils.isEven(2)).thenReturn(true);

        //invoke static method
        boolean result = MathUtils.isEven(2);

        //Assert the response
        Assert.assertTrue(result);
    }

    /* private method mocking*/
    @Test
    public void shouldReturnTrueForTheGivenOddNumber() throws Exception {
        //Mock private method
        MathUtils mock = PowerMockito.mock(MathUtils.class);

        //Set expectation
        PowerMockito.doReturn(true).when(mock, "isOdd",3);

        //invoke private method
        boolean invokeMethod = Whitebox.invokeMethod(mock, "isOdd",3);

        //Assert the response
        Assert.assertTrue(invokeMethod);
    }

    /* final method mocking */
    @Test
    public void shouldMockFinalMethod(){
        //Mock final method
        MathUtils mathUtilsMock = PowerMockito.mock(MathUtils.class);

        //Set expectation
        Mockito.when(mathUtilsMock.finalMessage()).thenReturn("Hello World!");

        //invoke the method
        String message = mathUtilsMock.finalMessage();

        //Assert the response
        Assert.assertEquals("Hello World!", message);
    }
}
